gio = float(input("Nhập số giờ: "))
tien_cong = float(input("Nhập tiền công mỗi giờ: "))
luong = gio * tien_cong
print("Lương:", luong)