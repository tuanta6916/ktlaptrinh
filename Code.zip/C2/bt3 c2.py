width =17
height = 12.0
print("width / 2 =", width / 2, "Kiểu:", type(width / 2))
print("width / 2.0 =", width / 2.0, "Kiểu:", type(width / 2.0))
print("height / 3 =", height / 3, "Kiểu:", type(height / 3))
print("1 + 2 * 5 =", 1 + 2 * 5, "Kiểu:", type(1 + 2 * 5))