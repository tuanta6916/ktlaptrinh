celsius = float(input("Nhập nhiệt độ theo độ C: "))
fahrenheit = (celsius * 9/5) + 32
print("Nhiệt độ theo độ F:", fahrenheit)