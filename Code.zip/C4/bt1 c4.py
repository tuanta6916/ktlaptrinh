def tinh_diem(diem):
    if diem > 1.0 or diem < 0.0:
        return "Điểm không hợp lệ"
    elif diem > 0.9:
        return "A"
    elif diem > 0.8:
        return "B"
    elif diem > 0.7:
        return "C"
    elif diem > 0.6:
        return "D"
    else:
        return "F"
try:
    nhap_diem = input("Nhập điểm (từ 0.0 đến 1.0): ")
    diem = float(nhap_diem)
    xep_loai = tinh_diem(diem)
except:
    xep_loai = "Điểm không hợp lệ"
print("Kết quả:", xep_loai)