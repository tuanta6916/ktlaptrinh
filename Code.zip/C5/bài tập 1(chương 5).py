total = 0
count = 0

while True:
    value = input("Enter a number: ")
    if value == "done":
        break
    try:
        number = float(value)
    except:
        print("Invalid input")
        continue
    total += number
    count += 1

if count > 0:
    average = total / count
    print(total, count, average)
else:
    print("No numbers entered")gio = float(input("Nhập số giờ: "))
tien_cong = float(input("Nhập tiền công mỗi giờ: "))
luong = gio * tien_cong
print("Lương:", luong)