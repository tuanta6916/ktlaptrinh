str = 'X-DSPAM-Confidence:0.8475'
a = str.find(':')
number = float(str[a+1:])
print(number)
