# Chuỗi ví dụ ban đầu
new = "   nguyễn hữu tuân   "

# 1) Dùng strip() để loại bỏ khoảng trắng ở đầu và cuối
clean_new = new.strip()
print("1-Sau khi strip():", clean_new)

# 2) Dùng replace() để thay thế chữ trong chuỗi
replaced_new = clean_new.replace(" ", "-")
print("2-Sau replace():", replaced_new)

# 3) Dùng find() để tìm vị trí 1 chữ con
a = replaced_new.find("tuân")
print("3-Vị trí của 'tuân':", a)

# 4) Dùng upper() để chuyển thành chữ in hoa
b = clean_new.upper()
print("4-Chữ in hoa:", b)

# 5) Dùng lower() để chuyển thành chữ thường
c = b.lower()
print("5-Chữ thường:", c)