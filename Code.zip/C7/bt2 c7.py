fname = input("Enter the file name: ")

try:
    fhand = open(fname)
except:
    print("File cannot be opened:", fname)
    quit()

count = 0
total = 0.0

for line in fhand:
    if not line.startswith("X-DSPAM-Confidence:"):
        continue
    value = float(line.split(":")[1])
    total += value
    count += 1

if count > 0:
    print("Average spam confidence:", total / count)
else:
    print("No X-DSPAM-Confidence lines found.")