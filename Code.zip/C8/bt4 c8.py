filename = input("Enter file: ")
words_list = []

with open(filename, 'r') as file:
    for line in file:
        words = line.split()  # tách từ
        for word in words:
            if word not in words_list:
                words_list.append(word)

words_list.sort()
print(words_list)
