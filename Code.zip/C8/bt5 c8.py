filename = input("Enter a file name: ")
count = 0

with open(filename, 'r') as file:
    for line in file:
        if line.startswith("From "):
            words = line.split()
            print(words[1])
            count += 1

print("There were", count, "lines in the file with From as the first word")
