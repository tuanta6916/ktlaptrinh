numbers = []

while True:
    value = input("Enter a number: ")
    if value == "done":
        break
    try:
        num = float(value)
        numbers.append(num)
    except:
        print("Invalid input")

if numbers:
    print("Maximum:", max(numbers))
    print("Minimum:", min(numbers))
